`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    19:55:08 06/23/2010 
// Design Name: 
// Module Name:    ALU 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module ALU(
	input wire [5:0] OPCODE,
	input wire [31:0] RA,
	input wire [31:0] RF_RA,
	input wire [31:0] RB,
	output reg [31:0] RD,
	input wire isR
    );

always @(*)
begin
	case({isR,2'h0,OPCODE})
		9'h120: RD = RA + RB;
		9'h08: RD = RA + RB;
		9'h124: RD = RA & RB;
		9'h0c: RD = RA & RB;
		9'h125: RD = RA | RB;
		9'h0d: RD = RA | RB;
		9'h128: RD = RA == RB ? 32'hFFFFFFFF : 32'h0;
		9'h18: RD = RA == RB ? 32'hFFFFFFFF : 32'h0;
		9'h12D: RD = RA >= RB ? 32'hFFFFFFFF : 32'h0;
		9'h1d: RD = RA >= RB ? 32'hFFFFFFFF : 32'h0;
		9'h12B: RD = RA > RB ? 32'hFFFFFFFF : 32'h0;
		9'h1b: RD = RA > RB ? 32'hFFFFFFFF : 32'h0;
		9'h12C: RD = RA <= RB ? 32'hFFFFFFFF : 32'h0;
		9'h1c: RD = RA <= RB ? 32'hFFFFFFFF : 32'h0;
		9'h104: RD = RA << (RB%8);
		9'h14: RD = RA << (RB%8);
		9'h12A: RD = RA < RB ? 32'hFFFFFFFF : 32'h0;
		9'h1a: RD = RA < RB ? 32'hFFFFFFFF : 32'h0;
		9'h129: RD = RA != RB ? 32'hFFFFFFFF : 32'h0;
		9'h19: RD = RA != RB ? 32'hFFFFFFFF : 32'h0;
		9'h107: RD = RA >> (RB%8); // FLAG
		9'h17: RD = RA >> (RB%8); // FLAG
		9'h106: RD = RA >> (RB%8); // FLAG
		9'h16: RD = RA >> (RB%8); // FLAG
		9'h122: RD = RA - RB;
		9'h0a: RD = RA - RB;
		9'h126: RD = RA ^ RB;
		9'h0e: RD = RA ^ RB;
		9'h0f: RD = RB << 16;
		9'h23: RD = RA + RB;
		9'h2b: RD = RA + RB;
		9'h04: RD = (RF_RA == 0) ? (RA + RB) : RA;
		9'h05: RD = (RF_RA != 0) ? (RA + RB) : RA;
		9'h02: RD = RA + RB;
		9'h03: RD = RA + RB;
		9'h13: RD = RA;
		9'h12: RD = RA;
		default: RD = 0;
	endcase
end

endmodule
