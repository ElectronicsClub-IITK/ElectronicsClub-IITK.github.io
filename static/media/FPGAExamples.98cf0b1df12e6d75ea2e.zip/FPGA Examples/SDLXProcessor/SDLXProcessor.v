`timescale 1us / 1ns
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    17:12:39 06/09/2010 
// Design Name: 
// Module Name:    SDLXProcessor 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module SDLXProcessor(
	input wire CLK,
	output wire LCD_E,
	output wire LCD_RS,
	output wire LCD_RW,
	output wire [3:0] LCD_DATA,
	output wire SF_CE0,
	output wire [7:0] LED_OUT
);
	 
reg [31:0] IR;
reg [29:0] PC;
reg PROC_EN;
wire [31:0] RA;
wire [31:0] RB;
wire [31:0] ALU_RD;
wire [31:0] RF_RA;
wire [31:0] RD;
wire [31:0] RF_RB;
wire isR;
wire [5:0] ALU_OPCODE;
wire [31:0] NewIR;
wire [4:0] RDSel;
wire isJ;
wire [31:0] RF_RD;
wire changePC;
wire [29:0] NewPC;
wire [29:0] PROGADR;
wire [7:0] DATAMEM_OUT;
reg DATAMEM_WE;
wire CONSTADD;
wire [31:0] EXTIR;

changePC change_PC(
	.Opcode(IR[31:26]),
	.changePC(changePC)
	);
	
REGFILE RegFile(
	.WE(1'h1),
	.RASel(IR[25:21]),
	.RA(RF_RA),
	.RBSel(IR[20:16]),
	.RB(RF_RB),
	.RDSel(((IR[31:26] == 6'h03) | (IR[31:26] == 6'h13)) ? 5'b11111 : RDSel),
	.RD(RF_RD),
	.CLK(CLK)
	);

ALU Alu(
	.RA(RA),
	.RF_RA(RF_RA),
	.RB(RB),
	.RD(ALU_RD),
	.OPCODE(ALU_OPCODE),
	.isR(isR)
	);

RDSSel #(.N(30)) PROGADRSEL(
	.R(NewPC),
	.RI(PC),
	.isR(changePC),
	.RSD(PROGADR)
	);

PROGMEM ProgMem(
	.OUT(NewIR),
	.ADR(PROGADR)
	);
	
DATAMEM DataMem(
	.IN(RF_RB[7:0]),
	.OUT(DATAMEM_OUT),
	.ADR(ALU_RD[9:0]),
	.CLK(CLK),
	.WE(DATAMEM_WE),
	.LCD_OUT({SF_CE0,LCD_E, LCD_RS, LCD_RW, LCD_DATA}),
	.LED_OUT(LED_OUT)
	);
	
initial
begin
	PROC_EN = 1;
	PC = 0;
	DATAMEM_WE = 0;
end

RDSSel #(.N(30)) PC_Sel(
	.R(ALU_RD[31:2]),
	.RI(PC + 30'h1),
	.isR(changePC),
	.RSD(NewPC)
	);
	
RDSSel #(.N(1)) PCCONSTADD(
	.R(1'h1),
	.RI(1'h0),
	.isR(changePC),
	.RSD(CONSTADD)
	);

always @(posedge CLK)
begin
	if (PROC_EN == 1)
	begin
		IR <= NewIR;
		if(PC < (1<<30-1))
			PC <= NewPC + CONSTADD;
		if(NewIR[31:26] == 6'h2b)
			DATAMEM_WE <= 1;
		else
			DATAMEM_WE <= 0;
	end
end

SignExtend EXTNDIR(
	.IR(IR[15:0]),
	.EXTIR(EXTIR)
	);
	
isR ISR(
	.IR(IR[31:26]),
	.isR(isR)
	);
	
RDSSel #(.N(32)) RBSel(
	.R(RF_RB),
	.RI(EXTIR),
	.isR(isR),
	.RSD(RB)
	);
	
RDSSel #(.N(6)) OPCODE_Sel(
	.R(IR[5:0]),
	.RI(IR[31:26]),
	.isR(isR),
	.RSD(ALU_OPCODE)
	);
	
RDSSel #(.N(5)) RDS_Sel(
	.R(IR[15:11]),
	.RI(IR[20:16]),
	.isR(isR),
	.RSD(RDSel)
	);

RDSSel #(.N(32)) RD_Sel(
	.R(ALU_RD),
	.RI({24'h000000, DATAMEM_OUT}),
	.isR((IR[31:26] != 6'h23)?1'h1:1'h0),
	.RSD(RD)
	);
	
isJ is_J(
	.Opcode(IR[31:26]),
	.isJ(isJ)
);
	
RDSSel #(.N(32)) RA_Sel(
	.R(32'h0 | (PC << 2)),
	.RI(RF_RA),
	.isR(isJ),
	.RSD(RA)
	);
	
RDSSel #(.N(32)) RD_Sel1(
	.R(RD),
	.RI((PC+1)<<2),
	.isR(((IR[31:26] == 6'h03) | (IR[31:26] == 6'h13)) ? 1'h0 : 1'h1),
	.RSD(RF_RD)
	);

endmodule
