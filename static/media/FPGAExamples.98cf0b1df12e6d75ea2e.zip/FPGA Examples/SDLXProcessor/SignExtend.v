`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    18:25:27 06/09/2010 
// Design Name: 
// Module Name:    SignExtend 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module SignExtend(
	input wire [15:0] IR,
	output reg [31:0] EXTIR
    );
	 
always @(*)
	if(IR[15] == 0)
		EXTIR = 32'h00000000 + IR;
	else
		EXTIR = 32'hFFFF0000 + IR;

endmodule
