`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    18:13:13 06/09/2010 
// Design Name: 
// Module Name:    isR 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module isR(
	input wire [31:26] IR,
	output reg isR
    );

always @(*)
	if(IR == 0)
		isR = 1;
	else
		isR = 0;

endmodule
