`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    18:03:18 06/26/2010 
// Design Name: 
// Module Name:    changePC 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module changePC(
	input wire [5:0] Opcode,
	output reg changePC
    );

always @(*)
	case (Opcode)
		6'h02: changePC = 1'h1;
		6'h03: changePC = 1'h1;
		6'h04: changePC = 1'h1;
		6'h05: changePC = 1'h1;
		6'h12: changePC = 1'h1;
		6'h13: changePC = 1'h1;
		default: changePC = 1'h0;
	endcase

endmodule
