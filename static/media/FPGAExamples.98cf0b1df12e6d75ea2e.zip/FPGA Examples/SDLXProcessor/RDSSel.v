`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    17:50:32 06/09/2010 
// Design Name: 
// Module Name:    RDSSel 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////

module RDSSel
#(parameter N = 6)
(

input wire [N-1:0] R,
input wire [N-1:0] RI,
input wire isR,
output reg [N-1:0] RSD 
    );
	
always @(*)
	if (isR == 1)
		RSD = R;
	else
		RSD = RI;


endmodule
