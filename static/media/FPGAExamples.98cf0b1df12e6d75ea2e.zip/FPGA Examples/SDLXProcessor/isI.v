`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    17:21:53 06/24/2010 
// Design Name: 
// Module Name:    isJ 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// RevisJon: 
// RevisJon 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module isJ(
input wire [5:0] Opcode,
output reg isJ
    );

always @(*)
case (Opcode)
6'h04: isJ = 1'h1;
6'h05: isJ = 1'h1;
6'h02: isJ = 1'h1;
6'h03: isJ = 1'h1;
default: isJ = 1'h0;
endcase

endmodule
