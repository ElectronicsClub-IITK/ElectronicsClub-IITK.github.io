`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    14:12:33 06/24/2010 
// Design Name: 
// Module Name:    DATAMEM 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module DATAMEM(
	input wire [9:0] ADR,
	input wire [7:0] IN,
	output wire [7:0] OUT,
	input wire WE,
	input wire CLK,
	output wire [7:0] LCD_OUT,
	output wire [7:0] LED_OUT
    );
	 
reg [7:0] RAM [0:10];

always @(posedge CLK)
	if (WE == 1)
		RAM[ADR] <= IN;
		
assign OUT = RAM[ADR];

assign LCD_OUT = RAM[0];
assign LED_OUT = RAM[1];

endmodule