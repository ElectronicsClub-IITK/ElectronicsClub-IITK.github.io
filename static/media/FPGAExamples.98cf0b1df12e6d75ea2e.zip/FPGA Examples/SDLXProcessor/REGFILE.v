`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    19:45:22 06/23/2010 
// Design Name: 
// Module Name:    REGFILE 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module REGFILE(
	input wire WE,
	input wire [4:0] RASel,
	output wire [31:0] RA,
	input wire [4:0] RBSel,
	output wire [31:0] RB,
	input wire [4:0] RDSel,
	input wire [31:0] RD,
	input wire CLK
    );

reg [31:0] RAM [0:31];

integer i;

initial
	for(i = 0; i < 32; i = i +1)
		RAM[i] = 0;

always @(posedge CLK)
	if (WE == 1 & RDSel != 0)
		RAM[RDSel] <= RD;

assign RA = RAM[RASel];
assign RB = RAM[RBSel];

endmodule
