`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    11:59:05 01/05/2011 
// Design Name: 
// Module Name:    SevenSegmentDecoder 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module SevenSegmentDecoder(
	input wire [3:0] inp,
	output wire[6:0] out
);

assign out[0] = ~inp[3] & ~inp[2] & ~inp[1] & inp[0]
| ~inp[3] & inp[2] & ~inp[1] & ~inp[0]
| inp[3] & ~inp[2] & inp[1] & inp[0]
| inp[3] & inp[2] & ~inp[1] & inp[0];

assign out[1] = ~inp[3] & inp[2] & ~inp[1] & inp[0]
| ~inp[3] & inp[2] & inp[1] & ~inp[0]
| inp[3] & ~inp[2] & inp[1] & inp[0]
| inp[3] & inp[2] & ~inp[1] & ~inp[0]
| inp[3] & inp[2] & inp[1];

assign out[2] = ~inp[3] & ~inp[2] & inp[1] & ~inp[0]
| inp[3] & inp[2] & ~inp[1] & ~inp[0]
| inp[3] & inp[2] & inp[1];

assign out[3] = ~inp[3] & ~inp[2] & ~inp[1] & inp[0]
| ~inp[3] & inp[2] & ~inp[1] & ~inp[0]
| ~inp[3] & inp[2] & inp[1] & inp[0]
| inp[3] & ~inp[2] & inp[1] & ~inp[0]
| inp[3] & inp[2] & inp[1] & inp[0];

assign out[4] = ~inp[3] & ~inp[2] & ~inp[1] & inp[0]
| ~inp[3] & ~inp[2] & inp[1] & inp[0]
| ~inp[3] & inp[2] & ~inp[1]
| ~inp[3] & inp[2] & inp[1] & inp[0]
| inp[3] & ~inp[2] & ~inp[1] & inp[0];

assign out[5] = ~inp[3] & ~inp[2] & ~inp[1] & inp[0]
| ~inp[3] & ~inp[2] & inp[1]
| ~inp[3] & inp[2] & inp[1] & inp[0]
| inp[3] & inp[2] & ~inp[1] & inp[0];

assign out[6] = ~inp[3] & ~inp[2] & ~inp[1]
| ~inp[3] & inp[2] & inp[1] & inp[0]
| inp[3] & inp[2] & ~inp[1] & ~inp[0];

endmodule