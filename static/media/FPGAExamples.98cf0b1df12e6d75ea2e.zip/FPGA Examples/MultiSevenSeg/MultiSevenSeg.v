`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    12:02:53 01/06/2011 
// Design Name: 
// Module Name:    MultiSevenSeg 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module MultiSevenSeg(
	input wire [3:0] INP,
	input wire TYPE,
	output reg [6:0] OUT);

wire [6:0] DecToInv;
wire [6:0] INVERTOUT;

SevenSegDec DECODER(
	.inp(INP),
	.out(DecToInv));

BusInverter #(.N(7)) INVERTER(
	.A(DecToInv),
	.B(INVERTOUT));

always @(*)
	OUT <= (TYPE == 1) ? DecToInv : INVERTOUT;

endmodule


