`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    12:03:13 01/06/2011 
// Design Name: 
// Module Name:    BusInverter 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module BusInverter #(parameter N = 7) (
	input wire [N-1:0] A,
	output wire [N-1:0] B
);

	assign B = ~A;

endmodule

