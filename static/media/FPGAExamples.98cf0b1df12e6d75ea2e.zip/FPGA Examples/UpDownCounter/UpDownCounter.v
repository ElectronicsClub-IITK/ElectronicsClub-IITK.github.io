`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    11:34:19 01/06/2011 
// Design Name: 
// Module Name:    UpDownCounter 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module UpDownCounter(
	input wire CLK,
	input wire DIR,
	output reg [7:0] COUNT);

initial
	COUNT <= 8'b0;

always @(posedge CLK)
	if (DIR == 1)
		COUNT <= COUNT + 1;
	else
		COUNT <= COUNT - 1;

endmodule
