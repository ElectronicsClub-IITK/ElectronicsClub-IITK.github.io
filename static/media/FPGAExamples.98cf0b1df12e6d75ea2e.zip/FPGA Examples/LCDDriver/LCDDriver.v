`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    18:48:50 06/15/2010 
// Design Name: 
// Module Name:    Loader 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Loader(
	output reg[7:4] LCDDATA,
	output reg LCD_RS,
	output reg LCD_RW,
	output reg LCD_E,
	input wire CLK
    );
	 
reg [25:0] FREQGEN;

initial
	FREQGEN = 0;


always @(posedge CLK)
begin
	if (FREQGEN == 46<<17)
		FREQGEN <= 12<<17;
	else
		FREQGEN <= FREQGEN + 1;
end

reg lcd_stb;
reg [5:0] lcd_code;
reg [6:0] lcd_stuff;

always @(posedge CLK)
begin
	case (FREQGEN[25:17])
       0: lcd_code <= 6'h03;        
       1: lcd_code <= 6'h03;
       2: lcd_code <= 6'h03;
       3: lcd_code <= 6'h02;
       4: lcd_code <= 6'h02;       
       5: lcd_code <= 6'h08;
       6: lcd_code <= 6'h00;        
       7: lcd_code <= 6'h06;
       8: lcd_code <= 6'h00;        
       9: lcd_code <= 6'h0C;
      10: lcd_code <= 6'h00;        
      11: lcd_code <= 6'h01;
      12: lcd_code <= 6'h00;        
      13: lcd_code <= 6'h02;
      14: lcd_code <= 6'h24;			// H  
      15: lcd_code <= 6'h28;
      16: lcd_code <= 6'h26;			// e  
      17: lcd_code <= 6'h25;
      18: lcd_code <= 6'h26;			// l  
      19: lcd_code <= 6'h2C;
      20: lcd_code <= 6'h26;			// l  
      21: lcd_code <= 6'h2C;
      22: lcd_code <= 6'h26;			// o  
      23: lcd_code <= 6'h2F;
      24: lcd_code <= 6'h22;			// <blank>  
      25: lcd_code <= 6'h20;
      26: lcd_code <= 6'h25;			// W  
      27: lcd_code <= 6'h27;
      28: lcd_code <= 6'h26;			// o  
      29: lcd_code <= 6'h2F;
      30: lcd_code <= 6'h27;			// r  
      31: lcd_code <= 6'h22;
      32: lcd_code <= 6'h26;			// l  
      33: lcd_code <= 6'h2C;
      34: lcd_code <= 6'h26;			// d  
      35: lcd_code <= 6'h24;
      36: lcd_code <= 6'h22;			// !  
      37: lcd_code <= 6'h21;
		
      default: lcd_code <= 6'h10;
    endcase
    lcd_stb <= ^FREQGEN[16:15] & ~LCD_RW ;
    lcd_stuff <= {lcd_stb,lcd_code};
    {LCD_E,LCD_RS,LCD_RW,LCDDATA} <= lcd_stuff; 
end



endmodule
