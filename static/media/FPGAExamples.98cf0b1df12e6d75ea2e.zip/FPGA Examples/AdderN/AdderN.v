`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    11:41:39 01/06/2011 
// Design Name: 
// Module Name:    AdderN 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module AdderN #(parameter N = 4) (
	input wire [N-1:0] IN1,
	input wire [N-1:0] IN2,
	output reg [N-1:0] OUT);

always @(*)
	OUT <= IN1 + IN2;

endmodule

