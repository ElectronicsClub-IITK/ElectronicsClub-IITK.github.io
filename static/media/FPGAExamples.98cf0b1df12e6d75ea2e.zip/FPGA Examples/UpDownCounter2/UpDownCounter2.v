`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    11:29:54 01/06/2011 
// Design Name: 
// Module Name:    UpDownCounter2 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module UpDownCounter2(
	input wire CLK,
	input wire DIR,
	output reg [7:0] COUNT);

initial
	COUNT <= 8'b0;

always @(posedge CLK)
	COUNT <= COUNT + ((DIR==1) ? 1 : -1);

endmodule
